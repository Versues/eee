package me.earth.phobos.features.modules.render;

import me.earth.phobos.features.modules.Module;

public class RenderTest
        extends Module {
    public RenderTest() {
        super("RenderTest", "RenderTest", Module.Category.RENDER, true, false, false);
    }
}

